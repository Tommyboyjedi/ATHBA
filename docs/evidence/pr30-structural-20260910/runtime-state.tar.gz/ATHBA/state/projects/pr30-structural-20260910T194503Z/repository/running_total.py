"""ATHBA initial production module."""


class RunningTotal:
    """A class for tracking running totals."""
    def __init__(self):
        self._total = 0.0
    
    def add(self, value):
        self._total += value
    
    def get_total(self):
        return self._total
    
    @property
    def total(self):
        return self._total
    
    def reset(self):
        self._total = 0.0