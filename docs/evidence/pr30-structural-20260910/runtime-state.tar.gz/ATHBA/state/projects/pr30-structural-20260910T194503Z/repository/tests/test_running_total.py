from running_total import RunningTotal

def test_REQ_001():
    instance = RunningTotal()
    assert instance.total == 0

def test_REQ_002():
    instance = RunningTotal()
    instance.add(10)
    assert instance.total == 10.0
    instance.add(-5)
    assert instance.total == 5.0

def test_REQ_003():
    instance = RunningTotal()
    instance.add(10)
    initial_total = instance.total
    assert instance.total == initial_total
    assert instance.total == 10.0

def test_REQ_004():
    instance = RunningTotal()
    instance.add(3)
    instance.add(-1)
    assert instance.total == 2.0
