import pytest
from running_total import RunningTotal

def test_REQ_001():
    rt = RunningTotal()
    assert rt.total == 0

def test_REQ_002():
    rt = RunningTotal()
    rt.add(10)
    assert rt.value() == 10
    rt.add(-5)
    assert rt.value() == 5
    rt.add(3)
    assert rt.value() == 8

def test_REQ_003():
    rt = RunningTotal()
    rt.add(10)
    assert rt.value() == 10
    assert rt.value() == 10

def test_REQ_004():
    rt = RunningTotal()
    rt.add(3)
    rt.add(-1)
    assert rt.value() == 2
