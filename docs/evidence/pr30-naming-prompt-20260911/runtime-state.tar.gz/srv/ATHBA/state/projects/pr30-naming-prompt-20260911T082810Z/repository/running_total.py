"""ATHBA initial production module."""

class RunningTotal:
    """Represents a running total calculation."""
    def __init__(self):
        self.total = 0
    
    def add(self, amount):
        self.total += amount
    
    def value(self):
        return self.total

