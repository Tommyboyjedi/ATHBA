"""ATHBA initial production module."""


class RunningTotal:
    def __init__(self):
        self.total = 0

    def add(self, value):
        self.total += value

    def get(self):
        return self.total
