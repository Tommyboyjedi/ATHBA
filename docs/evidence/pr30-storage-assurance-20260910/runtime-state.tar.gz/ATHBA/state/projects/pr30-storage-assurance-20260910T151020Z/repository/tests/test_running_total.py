from running_total import RunningTotal

def test_REQ_01():
    rt = RunningTotal()
    assert rt.total == 0

def test_REQ_02():
    rt = RunningTotal()
    rt.add(10)
    assert rt.total == 10
